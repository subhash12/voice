
import static org.mockserver.model.HttpRequest.request;
import static org.mockserver.model.HttpResponse.response;
import static org.mockserver.matchers.Times.exactly;
import static java.util.concurrent.TimeUnit.SECONDS;
import org.mockserver.client.server.MockServerClient;
import org.mockserver.model.Delay;
import org.mockserver.model.Header;

public class CreateExpectations  {
	
	//private static MockServerClient mockServerClient = new MockServerClient("127.0.0.1", 1090);
	
	public static void main(String[] args) { // createJSONExpectation() {
		MockServerClient mockServerClient = new MockServerClient("127.0.0.1", 1090);
		mockServerClient
		.when(
            request()
                    .withMethod("GET")
                    .withPath("/login1"),
            exactly(1)
		)
		.respond(
            response()
                    .withStatusCode(200)
                    .withHeaders(
                            new Header("Content-Type", "application/json; charset=utf-8"),
                            new Header("Cache-Control", "public, max-age=86400")
                    )
                    .withBody("{ message: 'Hello World' }")
                    .withDelay(new Delay(SECONDS, 1))
		);
		
		mockServerClient
		.when(
            request()
                    .withMethod("POST")
                    .withPath("/logout1"),
            exactly(1)
		)
		.respond(
            response()
                    .withStatusCode(200)
                    .withHeaders(
                            new Header("Content-Type", "application/json; charset=utf-8"),
                            new Header("Cache-Control", "public, max-age=86400")
                    )
                    .withBody("{ message: 'Bye World!' }")
                    .withDelay(new Delay(SECONDS, 1))
		);
	}
}
